from django.contrib import admin
from . models import Meat, Appetier, Vegetable, Fruit
# Register your models here
admin.site.register(Meat)
admin.site.register(Appetier)
admin.site.register(Vegetable)
admin.site.register(Fruit)
