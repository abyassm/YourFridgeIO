from django.apps import AppConfig


class RecipesConfig(AppConfig):
    name = 'recipes'
